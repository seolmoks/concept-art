import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
const require=createRequire(import.meta.url);
const {Miniflare}=createRequire(require.resolve('wrangler/package.json'))('miniflare');
import fs from 'node:fs/promises';
import crypto from 'node:crypto';
const root=fileURLToPath(new URL('..',import.meta.url)).replace(/\/$/,'');
const salt=crypto.randomBytes(16), password=crypto.randomBytes(24).toString('hex');
const hash=salt.toString('base64url')+'.'+crypto.pbkdf2Sync(password,salt,100000,32,'sha256').toString('base64url');
const mf=new Miniflare({modules:[{type:'ESModule',path:root+'/dist/server/index.js'},...(await fs.readdir(root+'/dist/server',{recursive:true})).filter(p=>p.endsWith('.js')&&p!=='index.js').map(p=>({type:'ESModule',path:root+'/dist/server/'+p}))],modulesRoot:root+'/dist/server',modulesRules:[{type:'ESModule',include:['**/*.js'],fallthrough:true}],compatibilityDate:'2026-05-15',compatibilityFlags:['nodejs_compat'],d1Databases:['DB'],r2Buckets:['BUCKET'],bindings:{ADMIN_USERNAME:'qa-owner',ADMIN_PASSWORD_HASH:hash,ADMIN_SESSION_SECRET:crypto.randomBytes(32).toString('hex')}});
try{
const db=await mf.getD1Database('DB');
for(const name of (await fs.readdir(root+'/drizzle')).filter(n=>n.endsWith('.sql')).sort())for(const q of (await fs.readFile(root+'/drizzle/'+name,'utf8')).split('--> statement-breakpoint'))if(q.trim())await db.prepare(q.trim()).run();
const get=(path,cookie)=>mf.dispatchFetch('https://archive.test'+path,{headers:cookie?{Cookie:cookie}:{}});
const post=(path,body,cookie,origin='https://archive.test')=>mf.dispatchFetch('https://archive.test'+path,{method:'POST',headers:{Origin:origin,'Content-Type':'application/json',...(cookie?{Cookie:cookie}:{})},body:JSON.stringify(body)});
function ok(value,message){if(!value)throw Error(message);console.log('PASS '+message)}
let r=await get('/');ok(r.status===200,'production home renders');await r.text();
r=await get('/login');const loginHtml=await r.text();ok(r.status===200&&loginHtml.includes('name="username"')&&loginHtml.includes('name="password"'),'separate login page has both credential fields');
r=await get('/admin');ok((await r.text()).includes('관리자 로그인'),'guest admin route requires login');
r=await post('/api/archive',{action:'save',title:'denied'});ok(r.status===403||r.status===401,'guest write rejected');
r=await post('/api/session',{action:'login',username:'qa-owner',password});ok(r.status===200,'production login accepted');const cookie=r.headers.get('set-cookie');ok(cookie?.includes('HttpOnly')&&cookie.includes('Secure'),'production response sets secure session cookie');
const token=cookie.split(';')[0];r=await get('/api/archive?mode=bootstrap',token);ok((await r.json()).admin===true,'session recognized on next request');
r=await get('/admin',token);ok((await r.text()).includes('관리 현황'),'owner dashboard renders');
r=await post('/api/archive',{action:'save'},token,'https://evil.test');ok(r.status===403,'cross origin write rejected');
r=await post('/api/session',{action:'logout'},token);ok(r.status===200&&r.headers.get('set-cookie').includes('Max-Age=0'),'logout clears session');
}finally{await mf.dispose()}
