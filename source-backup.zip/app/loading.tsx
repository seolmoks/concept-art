export default function Loading(){return <main className="route-loading" role="status" aria-live="polite"><span className="eyebrow">컨셉아트 아카이브</span><p>페이지를 불러오는 중입니다…</p></main>}
