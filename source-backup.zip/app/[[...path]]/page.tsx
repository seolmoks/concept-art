import Archive from '../archive';
import Login from '../login';
import {admin,config,runtime} from '@/lib/server';
export const dynamic='force-dynamic';
export default async function Page({params}:any){
  const {path=[]}=await params;
  const isAdmin=await admin();
  if(path[0]==='login'||(path[0]==='admin'&&!isAdmin))return <Login/>;
  const settings=await config();
  if(!isAdmin)settings.classifications=settings.classifications.filter((g:any)=>!g.hidden).map((g:any)=>({...g,items:g.items.filter((i:any)=>!i.hidden)}));
  return <Archive path={path} initialBoot={{admin:isAdmin,settings,aiReady:isAdmin&&!!runtime().OPENAI_API_KEY}}/>;
}
