import type {Metadata} from 'next';
import './globals.css';
export const metadata:Metadata={title:"컨셉아트 아카이브",description:'캐릭터의 시작과 세계를 기록하는 컨셉아트 갤러리',icons:{icon:'/favicon.svg'}};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="ko"><body>{children}</body></html>}
