const labels:Record<string,string> = {
  "Draft": "임시저장",
  "Private": "비공개",
  "Public": "공개",
  "Latest": "최신순",
  "Oldest": "오래된순",
  "A-Z": "영문순",
  "Recently Updated": "최근 수정순",
  "Order": "지정한 순서",
  "Main Art": "대표 그림",
  "Front": "정면",
  "Side": "측면",
  "Back": "후면",
  "Expressions": "표정",
  "Costume": "의상",
  "Props": "소품",
  "Early Design": "초기 디자인",
  "Revised Design": "수정 디자인",
  "Final Design": "최종 디자인",
  "Additional Concept": "추가 컨셉"
};
export function ko(value:string){return labels[value]??value}
