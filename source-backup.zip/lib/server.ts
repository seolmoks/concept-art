import {env} from 'cloudflare:workers';
import {cookies} from 'next/headers';
import {validSession,COOKIE} from './session';
import {defaultSettings} from './archive';
export const runtime=()=>env as any;
export const db=()=>{if(!runtime().DB)throw new Error('데이터 저장소를 사용할 수 없습니다.');return runtime().DB};
export async function admin(){const jar=await cookies();const token=jar.get(COOKIE)?.value;return validSession(token,runtime().ADMIN_SESSION_SECRET||'',runtime().ADMIN_USERNAME||'')}
export async function config(){const row=await db().prepare('SELECT data FROM settings WHERE id=?').bind('site').first();const result=row?JSON.parse(row.data):structuredClone(defaultSettings);if(result.title==='Concept Art Archive')result.title='컨셉아트 아카이브';return result}
export function entry(row:any){return {...JSON.parse(row.data),id:row.id,kind:row.kind,title:row.title,status:row.status,deleted:row.deleted,featured:row.featured,pinned:row.pinned,position:row.position,created:row.created,updated:row.updated}}
export function reply(x:any,status=200){return Response.json(x,{status,headers:{'Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff'}})}
export function sameOrigin(r:Request){const o=r.headers.get('origin');return !!o&&o===new URL(r.url).origin}
