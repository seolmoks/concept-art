'use client';
import React from 'react';

// Use native document navigation. This also works before hydration and avoids
// the production RSC dynamic-import failure in the bundled router.
export default function Link(props: React.ComponentProps<'a'>) {
  return <a {...props}/>;
}
export function useRouter() {
  return {
    push: (href: string) => window.location.assign(href),
    replace: (href: string) => window.location.replace(href),
    refresh: () => window.location.reload(),
    back: () => window.history.back(),
  };
}
